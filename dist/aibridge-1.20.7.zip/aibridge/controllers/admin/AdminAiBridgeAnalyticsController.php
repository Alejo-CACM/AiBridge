<?php

require_once dirname(__FILE__) . '/../../classes/AiBridgeAnalytics.php';

class AdminAiBridgeAnalyticsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;

        parent::__construct();
    }

    /**
     * This is a plain dashboard, not an ObjectModel list — $this->table is
     * intentionally left unset. renderList() is the hook ModuleAdminController
     * calls by default (no add/edit/view id in the request), so overriding
     * it and never calling parent::renderList() is the safe way to serve
     * fully custom content without fighting HelperList's table assumptions.
     */
    public function renderList()
    {
        list($from, $to, $preset) = $this->resolveRange();
        $analytics = new AiBridgeAnalytics();

        $productsLimit = $this->resolveLimit('products_limit');
        $brandsLimit = $this->resolveLimit('brands_limit');
        $customersLimit = $this->resolveLimit('customers_limit');

        $kpis = $analytics->kpis($from, $to);
        $salesByDay = $analytics->salesByDay($from, $to);
        $topProducts = $analytics->topProducts($from, $to, $productsLimit);
        $topBrands = $analytics->topBrands($from, $to, $brandsLimit);
        $topCustomers = $analytics->topCustomers($from, $to, $customersLimit);
        $inactiveCustomers = $analytics->inactiveCustomers(90);
        $lowStock = $analytics->lowStockProducts(5);
        $billingStatus = $analytics->wephoneBillingStatus($from, $to);
        $logLimit = $this->resolveLimit('log_limit');
        $systemLog = $analytics->systemLog($from, $to, $logLimit);

        return $this->renderRangeForm($from, $to, $preset)
            . ($billingStatus !== null ? $this->renderBillingStatus($billingStatus) : '')
            . $this->renderKpiCards($kpis)
            . $this->renderSalesByDay($salesByDay)
            . '<div class="row">'
            . '<div class="col-lg-6">' . $this->renderTopProducts($topProducts, $productsLimit) . '</div>'
            . '<div class="col-lg-6">' . $this->renderTopBrands($topBrands, $brandsLimit) . '</div>'
            . '</div>'
            . '<div class="row">'
            . '<div class="col-lg-6">' . $this->renderTopCustomers($topCustomers, $customersLimit) . '</div>'
            . '<div class="col-lg-6">' . $this->renderInactiveCustomers($inactiveCustomers) . '</div>'
            . '</div>'
            . $this->renderLowStock($lowStock)
            . $this->renderSystemLog($systemLog, $logLimit);
    }

    /**
     * Shared "how many rows" control for the top-N panels — kept out of
     * resolveRange() since it has nothing to do with the date range.
     */
    private function resolveLimit($paramName, $default = 10)
    {
        $allowed = array(10, 25, 50, 100);
        $value = (int) Tools::getValue($paramName, $default);

        return in_array($value, $allowed, true) ? $value : $default;
    }

    private function renderLimitSelect($paramName, $current)
    {
        $options = array(10, 25, 50, 100);
        $html = '<select onchange="this.form.submit()" name="' . $paramName . '" class="form-control" style="display:inline-block;width:auto;">';
        foreach ($options as $option) {
            $selected = $option === $current ? ' selected="selected"' : '';
            $html .= '<option value="' . $option . '"' . $selected . '>Top ' . $option . '</option>';
        }
        $html .= '</select>';

        return $html;
    }

    /**
     * Wraps a limit <select> in a form that resubmits the whole page with
     * every other GET param preserved as hidden fields, so changing "Top N"
     * on one panel doesn't reset the date range or the other panels' limits.
     */
    private function limitForm($paramName, $current)
    {
        $preserved = $_GET;
        unset($preserved[$paramName], $preserved['controller'], $preserved['token']);

        $html = '<form method="get" style="display:inline-block;float:right;">'
            . '<input type="hidden" name="controller" value="AdminAiBridgeAnalytics" />'
            . '<input type="hidden" name="token" value="' . Tools::safeOutput($this->token) . '" />';
        foreach ($preserved as $key => $value) {
            if (is_scalar($value)) {
                $html .= '<input type="hidden" name="' . Tools::safeOutput($key) . '" value="' . Tools::safeOutput((string) $value) . '" />';
            }
        }
        $html .= $this->renderLimitSelect($paramName, $current) . '</form>';

        return $html;
    }

    private function resolveRange()
    {
        $preset = (string) Tools::getValue('preset', '30d');
        $customFrom = (string) Tools::getValue('from', '');
        $customTo = (string) Tools::getValue('to', '');

        $today = new DateTime();
        $to = clone $today;
        $from = clone $today;

        switch ($preset) {
            case 'today':
                break;
            case '7d':
                $from->modify('-6 days');
                break;
            case 'this_month':
                $from->modify('first day of this month');
                break;
            case 'last_month':
                $from->modify('first day of last month');
                $to->modify('last day of last month');
                break;
            case 'custom':
                if ($customFrom !== '' && $customTo !== '') {
                    try {
                        $from = new DateTime($customFrom);
                        $to = new DateTime($customTo);
                    } catch (\Exception $exception) {
                        $preset = '30d';
                        $from = clone $today;
                        $from->modify('-29 days');
                    }
                }
                break;
            case '30d':
            default:
                $preset = '30d';
                $from->modify('-29 days');
                break;
        }

        if ($from > $to) {
            list($from, $to) = array($to, $from);
        }

        return array($from->format('Y-m-d'), $to->format('Y-m-d'), $preset);
    }

    private function renderRangeForm($from, $to, $preset)
    {
        $presets = array(
            'today' => 'Hoy',
            '7d' => 'Últimos 7 días',
            '30d' => 'Últimos 30 días',
            'this_month' => 'Este mes',
            'last_month' => 'Mes pasado',
        );

        $baseUrl = self::$currentIndex . '&token=' . $this->token;

        $html = '<div class="panel"><div class="panel-heading">'
            . '<i class="icon-bar-chart"></i> ' . $this->l('Analítica') . '</div><div style="padding:15px;">';

        foreach ($presets as $key => $label) {
            $active = $preset === $key ? ' btn-primary' : ' btn-default';
            $html .= '<a class="btn' . $active . '" style="margin-right:5px;margin-bottom:10px;" href="'
                . $baseUrl . '&preset=' . $key . '">' . $label . '</a>';
        }

        $html .= '<form method="get" style="display:inline-block;margin-left:15px;">'
            . '<input type="hidden" name="controller" value="AdminAiBridgeAnalytics" />'
            . '<input type="hidden" name="token" value="' . Tools::safeOutput($this->token) . '" />'
            . '<input type="hidden" name="preset" value="custom" />'
            . '<input type="date" name="from" value="' . Tools::safeOutput($from) . '" class="form-control" style="display:inline-block;width:auto;" />'
            . ' — <input type="date" name="to" value="' . Tools::safeOutput($to) . '" class="form-control" style="display:inline-block;width:auto;" />'
            . ' <button type="submit" class="btn btn-default">' . $this->l('Aplicar') . '</button>'
            . '</form>'
            . '<p class="help-block">' . sprintf($this->l('Período mostrado: %s a %s'), $from, $to) . '</p>'
            . '</div></div>';

        return $html;
    }

    /**
     * All orders entered in range regardless of payment status — the only
     * ones excluded are whichever state's name contains "cancel"
     * (AiBridgeAnalytics::excludeCancelledSql()). Deliberately independent
     * from the Wephone billing panel above: that one is about money
     * actually collected, this one is about order volume as PrestaShop's
     * own Orders screen would show it.
     */
    private function renderKpiCards(array $kpis)
    {
        $cards = array(
            array('label' => 'Pedidos', 'value' => (string) $kpis['orders_count']),
            array('label' => 'Ventas', 'value' => $this->formatMoney($kpis['revenue'])),
            array('label' => 'Ticket promedio', 'value' => $this->formatMoney($kpis['avg_order'])),
            array('label' => 'Clientes nuevos', 'value' => (string) $kpis['new_customers']),
        );

        $html = '<div class="panel"><div class="panel-heading"><i class="icon-shopping-cart"></i> '
            . $this->l('Pedidos (PrestaShop)') . '</div>'
            . '<p class="help-block" style="padding:0 15px;">'
            . $this->l('Todos los pedidos del período, sin importar si están pagados — excluye solo los cancelados.')
            . '</p><div class="row" style="padding:0 15px 15px;">';
        foreach ($cards as $card) {
            $html .= '<div class="col-lg-3 col-md-6" style="text-align:center;padding:15px;">'
                . '<div style="font-size:26px;font-weight:bold;">' . Tools::safeOutput($card['value']) . '</div>'
                . '<div class="text-muted">' . Tools::safeOutput($card['label']) . '</div>'
                . '</div>';
        }
        $html .= '</div></div>';

        return $html;
    }

    /**
     * Only rendered when the "wephonebackofficecolumns" module's billing
     * table exists — reflects real accounting status (invoice issued +
     * marked paid by an employee), not just PrestaShop's own order state.
     */
    private function renderBillingStatus(array $status)
    {
        $cards = array(
            array('label' => 'Pagado', 'value' => $this->formatMoney($status['paid_amount']) . ' (' . $status['paid_count'] . ')', 'color' => '#5cb85c'),
            array('label' => 'Facturado, por cobrar', 'value' => $this->formatMoney($status['pending_amount']) . ' (' . $status['pending_count'] . ')', 'color' => '#f0ad4e'),
            array('label' => 'Sin facturar', 'value' => (string) $status['not_invoiced_count'] . ' pedidos', 'color' => '#d9534f'),
        );

        $html = '<div class="panel"><div class="panel-heading"><i class="icon-money"></i> '
            . $this->l('Estado de facturación (Wephone)') . '</div><div class="row" style="padding:15px;">';

        foreach ($cards as $card) {
            $html .= '<div class="col-lg-4"><div style="text-align:center;padding:15px;border-left:4px solid ' . $card['color'] . ';">'
                . '<div style="font-size:20px;font-weight:bold;">' . Tools::safeOutput($card['value']) . '</div>'
                . '<div class="text-muted">' . Tools::safeOutput($card['label']) . '</div>'
                . '</div></div>';
        }

        $html .= '</div></div>';

        return $html;
    }

    private function renderSalesByDay(array $rows)
    {
        $html = '<div class="panel"><div class="panel-heading"><i class="icon-calendar"></i> '
            . $this->l('Ventas por día') . '</div>';

        if (!$rows) {
            return $html . '<p class="help-block" style="padding:15px;">' . $this->l('Sin ventas en este período.') . '</p></div>';
        }

        $maxRevenue = max(array_map(function ($row) { return (float) $row['revenue']; }, $rows));
        $maxRevenue = $maxRevenue > 0 ? $maxRevenue : 1;

        $html .= '<table class="table"><thead><tr>'
            . '<th>' . $this->l('Fecha') . '</th>'
            . '<th>' . $this->l('Pedidos') . '</th>'
            . '<th>' . $this->l('Ventas') . '</th>'
            . '<th style="width:40%;"></th>'
            . '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $revenue = (float) $row['revenue'];
            $barWidth = max(2, round(($revenue / $maxRevenue) * 100));
            $html .= '<tr><td>' . Tools::safeOutput($row['d']) . '</td>'
                . '<td>' . (int) $row['orders_count'] . '</td>'
                . '<td>' . $this->formatMoney($revenue) . '</td>'
                . '<td><div style="background:#5cb85c;height:14px;width:' . $barWidth . '%;border-radius:2px;"></div></td>'
                . '</tr>';
        }

        $html .= '</tbody></table></div>';

        return $html;
    }

    private function renderTopProducts(array $rows, $limit)
    {
        $html = '<div class="panel"><div class="panel-heading"><i class="icon-cubes"></i> '
            . $this->l('Productos más vendidos') . $this->limitForm('products_limit', $limit) . '</div>';

        if (!$rows) {
            return $html . '<p class="help-block" style="padding:15px;">' . $this->l('Sin datos en este período.') . '</p></div>';
        }

        $html .= '<table class="table"><thead><tr>'
            . '<th>' . $this->l('Producto') . '</th>'
            . '<th>' . $this->l('Cantidad') . '</th>'
            . '<th>' . $this->l('Ingresos') . '</th>'
            . '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $editUrl = $this->context->link->getAdminLink('AdminProducts') . '&id_product=' . (int) $row['product_id'] . '&updateproduct';
            $html .= '<tr><td><a href="' . Tools::safeOutput($editUrl) . '">' . Tools::safeOutput((string) $row['product_name']) . '</a></td>'
                . '<td>' . (int) $row['qty_sold'] . '</td>'
                . '<td>' . $this->formatMoney((float) $row['revenue']) . '</td>'
                . '</tr>';
        }

        $html .= '</tbody></table></div>';

        return $html;
    }

    private function renderTopBrands(array $rows, $limit)
    {
        $html = '<div class="panel"><div class="panel-heading"><i class="icon-tags"></i> '
            . $this->l('Marcas más vendidas') . $this->limitForm('brands_limit', $limit) . '</div>';

        if (!$rows) {
            return $html . '<p class="help-block" style="padding:15px;">' . $this->l('Sin datos en este período.') . '</p></div>';
        }

        $html .= '<table class="table"><thead><tr>'
            . '<th>' . $this->l('Marca') . '</th>'
            . '<th>' . $this->l('Cantidad') . '</th>'
            . '<th>' . $this->l('Ingresos') . '</th>'
            . '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $editUrl = $this->context->link->getAdminLink('AdminManufacturers') . '&id_manufacturer=' . (int) $row['id_manufacturer'] . '&updatemanufacturer';
            $html .= '<tr><td><a href="' . Tools::safeOutput($editUrl) . '">' . Tools::safeOutput((string) $row['manufacturer_name']) . '</a></td>'
                . '<td>' . (int) $row['qty_sold'] . '</td>'
                . '<td>' . $this->formatMoney((float) $row['revenue']) . '</td>'
                . '</tr>';
        }

        $html .= '</tbody></table></div>';

        return $html;
    }

    private function renderTopCustomers(array $rows, $limit)
    {
        $html = '<div class="panel"><div class="panel-heading"><i class="icon-user"></i> '
            . $this->l('Clientes top') . $this->limitForm('customers_limit', $limit) . '</div>';

        if (!$rows) {
            return $html . '<p class="help-block" style="padding:15px;">' . $this->l('Sin datos en este período.') . '</p></div>';
        }

        $html .= '<table class="table"><thead><tr>'
            . '<th>' . $this->l('Cliente') . '</th>'
            . '<th>' . $this->l('Pedidos') . '</th>'
            . '<th>' . $this->l('Gastado') . '</th>'
            . '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $editUrl = $this->context->link->getAdminLink('AdminCustomers') . '&id_customer=' . (int) $row['id_customer'] . '&viewcustomer';
            $label = trim($row['firstname'] . ' ' . $row['lastname']) . ' <span class="text-muted">(' . $row['email'] . ')</span>';
            $html .= '<tr><td><a href="' . Tools::safeOutput($editUrl) . '">' . $label . '</a></td>'
                . '<td>' . (int) $row['orders_count'] . '</td>'
                . '<td>' . $this->formatMoney((float) $row['spent']) . '</td>'
                . '</tr>';
        }

        $html .= '</tbody></table></div>';

        return $html;
    }

    private function renderInactiveCustomers(array $rows)
    {
        $html = '<div class="panel"><div class="panel-heading"><i class="icon-user-times"></i> '
            . $this->l('Clientes sin comprar hace más de 90 días') . '</div>';

        if (!$rows) {
            return $html . '<p class="help-block" style="padding:15px;">' . $this->l('No hay clientes inactivos.') . '</p></div>';
        }

        $html .= '<table class="table"><thead><tr>'
            . '<th>' . $this->l('Cliente') . '</th>'
            . '<th>' . $this->l('Último pedido') . '</th>'
            . '<th>' . $this->l('Días inactivo') . '</th>'
            . '<th>' . $this->l('Pedidos totales') . '</th>'
            . '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $editUrl = $this->context->link->getAdminLink('AdminCustomers') . '&id_customer=' . (int) $row['id_customer'] . '&viewcustomer';
            $label = trim($row['firstname'] . ' ' . $row['lastname']) . ' <span class="text-muted">(' . $row['email'] . ')</span>';
            $html .= '<tr><td><a href="' . Tools::safeOutput($editUrl) . '">' . $label . '</a></td>'
                . '<td>' . Tools::safeOutput(substr((string) $row['last_order_at'], 0, 10)) . '</td>'
                . '<td>' . (int) $row['days_inactive'] . '</td>'
                . '<td>' . (int) $row['orders_total'] . '</td>'
                . '</tr>';
        }

        $html .= '</tbody></table></div>';

        return $html;
    }

    private function renderLowStock(array $rows)
    {
        $html = '<div class="panel"><div class="panel-heading"><i class="icon-warning-sign"></i> '
            . $this->l('Stock bajo (≤5 unidades)') . '</div>';

        if (!$rows) {
            return $html . '<p class="help-block" style="padding:15px;">' . $this->l('Ningún producto activo con stock bajo.') . '</p></div>';
        }

        $html .= '<table class="table"><thead><tr>'
            . '<th>' . $this->l('Producto') . '</th>'
            . '<th>' . $this->l('Stock') . '</th>'
            . '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $editUrl = $this->context->link->getAdminLink('AdminProducts') . '&id_product=' . (int) $row['id_product'] . '&updateproduct';
            $quantity = (int) $row['quantity'];
            $badge = $quantity <= 0 ? 'label-danger' : 'label-warning';
            $html .= '<tr><td><a href="' . Tools::safeOutput($editUrl) . '">' . Tools::safeOutput((string) $row['name']) . '</a></td>'
                . '<td><span class="label ' . $badge . '">' . $quantity . '</span></td>'
                . '</tr>';
        }

        $html .= '</tbody></table></div>';

        return $html;
    }

    /**
     * ps_log is PrestaShop's own error/warning log (PrestaShopLogger) — not
     * a full "who changed what" audit trail (PrestaShop has none built in),
     * but real signal for "did the system or a module misbehave".
     */
    private function renderSystemLog(array $rows, $limit)
    {
        $severityLabels = array(
            1 => array('Info', 'label-info'),
            2 => array('Aviso', 'label-warning'),
            3 => array('Error', 'label-danger'),
            4 => array('Error grave', 'label-danger'),
        );

        $html = '<div class="panel"><div class="panel-heading"><i class="icon-list-alt"></i> '
            . $this->l('Registro del sistema (PrestaShop)') . $this->limitForm('log_limit', $limit) . '</div>'
            . '<p class="help-block" style="padding:0 15px;">'
            . $this->l('Errores y avisos que PrestaShop y los módulos instalados registran por su cuenta. No es un historial de cambios manuales — PrestaShop no guarda eso de fábrica.')
            . '</p>';

        if (!$rows) {
            return $html . '<p class="help-block" style="padding:0 15px 15px;">' . $this->l('Sin entradas en este período.') . '</p></div>';
        }

        $html .= '<table class="table"><thead><tr>'
            . '<th>' . $this->l('Fecha') . '</th>'
            . '<th>' . $this->l('Nivel') . '</th>'
            . '<th>' . $this->l('Mensaje') . '</th>'
            . '<th>' . $this->l('Origen') . '</th>'
            . '<th>' . $this->l('Empleado') . '</th>'
            . '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $severity = (int) $row['severity'];
            $severityLabel = $severityLabels[$severity] ?? array('Nivel ' . $severity, 'label-default');
            $employee = trim((string) $row['firstname'] . ' ' . (string) $row['lastname']);
            $origin = trim((string) $row['object_type'] . ' ' . ($row['object_id'] ? '#' . (int) $row['object_id'] : ''));

            $html .= '<tr><td>' . Tools::safeOutput((string) $row['date_add']) . '</td>'
                . '<td><span class="label ' . $severityLabel[1] . '">' . $severityLabel[0] . '</span></td>'
                . '<td>' . Tools::safeOutput((string) $row['message']) . '</td>'
                . '<td>' . Tools::safeOutput($origin) . '</td>'
                . '<td>' . ($employee !== '' ? Tools::safeOutput($employee) : '<span class="text-muted">-</span>') . '</td>'
                . '</tr>';
        }

        $html .= '</tbody></table></div>';

        return $html;
    }

    private function formatMoney($value)
    {
        return Tools::displayPrice((float) $value, (int) $this->context->currency->id);
    }
}
